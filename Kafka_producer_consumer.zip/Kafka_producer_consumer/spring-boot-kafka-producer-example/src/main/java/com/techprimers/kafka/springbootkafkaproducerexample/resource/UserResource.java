package com.techprimers.kafka.springbootkafkaproducerexample.resource;

        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.kafka.annotation.KafkaListener;
        import org.springframework.kafka.core.KafkaTemplate;
        import org.springframework.web.bind.annotation.GetMapping;
        import org.springframework.web.bind.annotation.PathVariable;
        import org.springframework.web.bind.annotation.RequestMapping;
        import org.springframework.web.bind.annotation.RestController;

        import java.sql.Connection;
        import java.sql.DriverManager;
        import java.sql.PreparedStatement;
        import java.sql.SQLException;
//hi
@RestController
@RequestMapping("kafka")
public class UserResource {

    @Autowired
    private KafkaTemplate<String,String> kafkaTemplate;

    public static String TOPIC = "first";

    @GetMapping("/publish")
    public String post(){

        kafkaTemplate.send(TOPIC,"hello_first");

        return "Published successfully";
    }
    @GetMapping("/start")
    @KafkaListener(topics="second",groupId = "group_id")
    public void consume(String message)
    {
        String jdbcURL = "jdbc:postgresql://localhost:5432/consumer";
        String username = "postgres";
        String password = "toor";
        try {
            Connection connection = DriverManager.getConnection(jdbcURL, username, password);
            System.out.println("Connected");
            String query= "INSERT INTO incoming_message (message_second) VALUES (?)";
            PreparedStatement statement= connection.prepareStatement(query);
            statement.setString(1,message);
            int rows = statement.executeUpdate();
            if(rows>0)
            {
                System.out.println("A new message is inserted");
                TOPIC="first";
                kafkaTemplate.send(TOPIC,"hello");
            }
            connection.close();
        } catch (
                SQLException e) {
            System.out.println("Error in connecting to postgresql");
            e.printStackTrace();
        }

        System.out.println("message = " + message);
    }
    @GetMapping("/stop")
    public void stop(){

        System.exit(1);
    }
}
