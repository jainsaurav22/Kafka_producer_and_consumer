package com.techprimers.kafka.springbootkafkaproducerexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootKafkaProducerExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
