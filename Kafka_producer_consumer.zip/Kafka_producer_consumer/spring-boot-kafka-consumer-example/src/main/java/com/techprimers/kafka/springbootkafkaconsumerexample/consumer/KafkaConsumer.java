package com.techprimers.kafka.springbootkafkaconsumerexample.consumer;

import org.apache.kafka.common.internals.Topic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Component
public class KafkaConsumer {
    public static String TOPIC;
    @Autowired
    private KafkaTemplate<String,String> kafkaTemplate;
    @KafkaListener(topics="first",groupId = "group_id")
    public void consume(String message)
    {
        String jdbcURL = "jdbc:postgresql://localhost:5432/consumer";
        String username = "postgres";
        String password = "toor";
        try {
            Connection connection = DriverManager.getConnection(jdbcURL, username, password);
            System.out.println("Connected");
            String query= "INSERT INTO incoming_message (message) VALUES (?)";
            PreparedStatement statement= connection.prepareStatement(query);
            statement.setString(1,message);
            int rows = statement.executeUpdate();
            if(rows>0)
            {
                System.out.println("A new message is inserted");
                TOPIC="second";
                kafkaTemplate.send(TOPIC,"hii_second");
            }
            connection.close();
        } catch (
                SQLException e) {
            System.out.println("Error in connecting to postgresql");
            e.printStackTrace();
        }

        System.out.println("message = " + message);
    }
}
